/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * Licensed under the Oculus SDK License Agreement (the "License");
 * you may not use the Oculus SDK except in compliance with the License,
 * which is provided at the time of installation or download, or which
 * otherwise accompanies this software in either electronic or hard copy form.
 *
 * You may obtain a copy of the License at
 *
 * https://developer.oculus.com/licenses/oculussdk/
 *
 * Unless required by applicable law or agreed to in writing, the Oculus SDK
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

using System.Collections.Generic;
using Meta.XR.Telemetry;
using Meta.XR.Util;
using UnityEngine;

namespace Meta.XR.MRUtilityKit
{
    /// <summary>
    /// This class uses the current <see cref="MRUKRoom"/> boundaries to draw their visual representation similarly to what the guardian does at a system level
    /// to indicate the limit of the physical space defined by the user.
    /// </summary>
    [HelpURL("https://developers.meta.com/horizon/reference/mruk/latest/class_meta_x_r_m_r_utility_kit_room_guardian")]
    [Feature(Feature.Scene)]
    public class RoomGuardian : MonoBehaviour
    {
        /// <summary>
        /// Material to use for the Guardian effect
        /// </summary>
        [Tooltip("Material to use for the Guardian effect")]
        public Material GuardianMaterial;

        /// <summary>
        /// This is how far, in meters, the player must be from a surface for the Guardian to become visible (
        /// in other words, it blends `_GuardianFade` from 0 to 1). The position of the
        /// user is calculated as a point 0.2m above the ground. This is to catch tripping hazards
        /// as well as walls. All <see cref="MRUKAnchor"/>s but the floor and ceiling are considered
        /// for this calculation.
        /// </summary>
        [Tooltip("This is how far, in meters, the player must be from a surface for the Guardian to become visible (in other words, it blends `_GuardianFade` from 0 to 1). The position of the user is calculated as a point 0.2m above the ground. This is to catch tripping hazards, as well as walls.")]
        public float GuardianDistance = 1.0f;

        /// <summary>
        /// Initializes the RoomGuardian component by configuring passthrough blending and starting telemetry.
        /// </summary>
        private void Start()
        {
            // required for passthrough blending to work properly
            OVRPlugin.eyeFovPremultipliedAlphaModeEnabled = false;
            var unifiedEvent = new UnifiedEventData(TelemetryConstants.EventName.LoadRoomGuardian);
            unifiedEvent.SendMRUKEvent();
        }

        /// <summary>
        /// Updates the Guardian effect by calculating the distance to the nearest surface and adjusting the fade value.
        /// The Guardian becomes more visible as the user approaches room boundaries.
        /// </summary>
        private void Update()
        {
            if (GuardianMaterial == null)
            {
                return;
            }

            // get the closest distance of all the surfaces
            // should avoid raycasting if possible
            var room = MRUK.Instance?.GetCurrentRoom();
            if (!room)
            {
                return;
            }

            bool insideRoom = room.IsPositionInRoom(Camera.main.transform.position);

            // instead of using the head position, we actually want a position near the feet
            // (to catch short volumes like a bed, which are a tripping hazard)
            Vector3 testPosition = new Vector3(Camera.main.transform.position.x, 0.2f, Camera.main.transform.position.z);

            float closestDistance =
                room.TryGetClosestSurfacePosition(testPosition, out Vector3 closestPoint, out _, new LabelFilter(~(MRUKAnchor.SceneLabels.FLOOR | MRUKAnchor.SceneLabels.CEILING)));

            bool outsideVolume = !room.IsPositionInSceneVolume(testPosition);

            float guardianFade = insideRoom && outsideVolume ? Mathf.Clamp01(1 - (closestDistance / GuardianDistance)) : 1.0f;
            GuardianMaterial.SetFloat("_GuardianFade", guardianFade);

            Color lineColor = insideRoom ? Color.green : Color.red;
            Debug.DrawLine(testPosition, closestPoint, lineColor);
        }
    }
}
